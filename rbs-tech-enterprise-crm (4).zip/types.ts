
export enum UserRole {
  DIRECTOR = 'Director',
  HR = 'HR',
  GENERAL_MANAGER = 'General Manager',
  MANAGER = 'Manager',
  SALES = 'Sales Agent'
}

// Branch is now dynamic, so we use string for the type
export type Branch = string;

export enum QCStatus {
  PENDING = 'Pending QC',
  APPROVED = 'Approved',
  REJECTED = 'Rejected',
  HOLD = 'Hold'
}

export enum ProcessingStatus {
  PENDING = 'Pending Processing',
  PROCESSED = 'Sales Processed',
  REJECTED = 'Sale Rejected',
  HOLD = 'Sale On Hold'
}

export enum PremiumStatus {
  PENDING = 'Awaiting Date',
  CHARGED = 'Premium Charged',
  DECLINED = 'Premium Declined'
}

export interface User {
  id: string;
  username: string;
  password?: string;
  role: UserRole;
  branch: Branch;
  fullName: string;
  baseSalary: number;
}

export interface SaleRecord {
  id: string;
  createdAt: string;
  frontierName: string;
  frontierBranch: Branch;
  closerName: string;
  closerBranch: Branch;
  closerId?: string; // Links to a User
  customerName: string;
  customerNumber: string;
  email: string;
  streetAddress: string;
  city: string;
  zipCode: string;
  state: string;
  carMake: string;
  carModel: string;
  carYear: number;
  mileage: number;
  policyPrice: number;
  monthlyPremium: number;
  qcStatus: QCStatus;
  qcNotes: string;
  processingStatus: ProcessingStatus;
  carrier?: string;
  processingComments: string;
  actualPremiumAmount?: number;
  premiumDueDate?: string;
  premiumStatus: PremiumStatus;
  declinedReason?: string;
  incomeUpdated: boolean;
  retentionCall1Done: boolean;
  retentionCall2Done: boolean;
}

export interface ExpenseRecord {
  id: string;
  date: string;
  category: string;
  amount: number;
  notes: string;
}

export interface AttendanceRecord {
  id: string;
  userId: string;
  date: string;
  status: 'Present' | 'Absent' | 'Late' | 'Leave';
}

export interface CRMState {
  sales: SaleRecord[];
  expenses: ExpenseRecord[];
  users: User[];
  attendance: AttendanceRecord[];
  branches: Branch[];
}

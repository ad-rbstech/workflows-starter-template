
import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, FilePlus, CheckCircle, Truck, 
  DollarSign, BarChart3, Users, Settings, Bell, 
  Search, TrendingUp, Shield, Briefcase, LogOut,
  PhoneCall,
  ShieldAlert
} from 'lucide-react';
import { CRMState, SaleRecord, ExpenseRecord, User, UserRole, QCStatus, ProcessingStatus, PremiumStatus } from './types';
import Dashboard from './components/Dashboard';
import SaleForm from './components/SaleForm';
import SalesManagement from './components/SalesManagement';
import Financials from './components/Financials';
import HRModule from './components/HRModule';
import AdminConsole from './components/AdminConsole';
import Login from './components/Login';

const AccessDenied: React.FC<{ role: string }> = ({ role }) => (
  <div className="flex flex-col items-center justify-center min-h-[60vh] bg-white rounded-3xl border border-rose-100 shadow-sm p-12 text-center animate-fadeIn">
    <div className="bg-rose-50 p-6 rounded-full mb-6">
      <ShieldAlert className="w-16 h-16 text-rose-500" />
    </div>
    <h2 className="text-3xl font-black text-slate-800 mb-4">Access Restricted</h2>
    <p className="text-slate-500 max-w-md mx-auto leading-relaxed">
      Your current role (<span className="font-bold text-rose-600">{role}</span>) does not have the necessary permissions to access this module. If you believe this is an error, please contact your system administrator.
    </p>
    <button 
      onClick={() => window.location.reload()} 
      className="mt-8 px-8 py-3 bg-slate-900 text-white font-bold rounded-xl hover:bg-slate-800 transition-all shadow-lg"
    >
      Return to Dashboard
    </button>
  </div>
);

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('crm_user');
    return saved ? JSON.parse(saved) : null;
  });
  
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  
  const [state, setState] = useState<CRMState>(() => {
    const saved = localStorage.getItem('autoshield_crm_data_v3');
    if (saved) return JSON.parse(saved);
    return { 
      sales: [], 
      expenses: [], 
      users: [], 
      attendance: [],
      branches: ['RBS', 'Bahria', 'Lahore', 'Outsource Partner 1', 'Outsource Partner 2']
    };
  });

  useEffect(() => {
    localStorage.setItem('autoshield_crm_data_v3', JSON.stringify(state));
  }, [state]);

  const handleLogin = (u: User) => {
    setUser(u);
    localStorage.setItem('crm_user', JSON.stringify(u));
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('crm_user');
  };

  const updateState = (key: keyof CRMState, value: any) => {
    setState(prev => ({ ...prev, [key]: value }));
  };

  if (!user) {
    return <Login onLogin={handleLogin} />;
  }

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: [UserRole.DIRECTOR, UserRole.HR, UserRole.GENERAL_MANAGER, UserRole.MANAGER] },
    { id: 'new-sale', label: 'New Sale', icon: FilePlus, roles: [UserRole.DIRECTOR, UserRole.MANAGER, UserRole.SALES] },
    { id: 'qc', label: 'Quality Check', icon: CheckCircle, roles: [UserRole.DIRECTOR, UserRole.GENERAL_MANAGER, UserRole.MANAGER] },
    { id: 'processing', label: 'Processing', icon: Truck, roles: [UserRole.DIRECTOR, UserRole.GENERAL_MANAGER, UserRole.MANAGER] },
    { id: 'premiums', label: 'Premium Status', icon: DollarSign, roles: [UserRole.DIRECTOR, UserRole.MANAGER] },
    { id: 'retention', label: 'Retention', icon: PhoneCall, roles: [UserRole.DIRECTOR, UserRole.MANAGER, UserRole.HR, UserRole.GENERAL_MANAGER] },
    { id: 'financials', label: 'Financials', icon: BarChart3, roles: [UserRole.DIRECTOR, UserRole.HR, UserRole.GENERAL_MANAGER] },
    { id: 'hr', label: 'HR Module', icon: Briefcase, roles: [UserRole.DIRECTOR, UserRole.HR] },
    { id: 'admin', label: 'Admin Console', icon: Shield, roles: [UserRole.DIRECTOR, UserRole.HR, UserRole.GENERAL_MANAGER] },
    { id: 'all-sales', label: 'Sales Ledger', icon: Users, roles: [UserRole.DIRECTOR, UserRole.HR, UserRole.GENERAL_MANAGER, UserRole.MANAGER] },
  ];

  const allowedTabs = navItems.filter(item => item.roles.includes(user.role));

  const renderContent = () => {
    const handleUpdateSale = (id: string, up: Partial<SaleRecord>) => {
      updateState('sales', state.sales.map(s => s.id === id ? { ...s, ...up } : s));
    };

    // Strict Permission Guard
    const currentNavItem = navItems.find(item => item.id === activeTab);
    if (currentNavItem && !currentNavItem.roles.includes(user.role)) {
      return <AccessDenied role={user.role} />;
    }

    switch (activeTab) {
      case 'dashboard': return <Dashboard state={state} user={user} />;
      case 'new-sale': return <SaleForm onSubmit={(s) => updateState('sales', [s, ...state.sales])} currentUser={user} branches={state.branches} />;
      case 'qc': return (
        <SalesManagement 
          title="Quality Check Queue" 
          sales={state.sales.filter(s => s.qcStatus === QCStatus.PENDING || s.qcStatus === QCStatus.HOLD)} 
          onUpdate={handleUpdateSale}
          type="qc"
        />
      );
      case 'processing': return (
        <SalesManagement 
          title="Processing Department" 
          sales={state.sales.filter(s => s.qcStatus === QCStatus.APPROVED && s.processingStatus !== ProcessingStatus.PROCESSED)} 
          onUpdate={handleUpdateSale}
          type="processing"
        />
      );
      case 'premiums': return (
        <SalesManagement 
          title="Premium Tracking" 
          sales={state.sales.filter(s => s.processingStatus === ProcessingStatus.PROCESSED && s.premiumStatus === PremiumStatus.PENDING)} 
          onUpdate={handleUpdateSale}
          type="premium"
        />
      );
      case 'retention': return (
        <SalesManagement 
          title="Customer Retention Desk" 
          sales={state.sales.filter(s => s.premiumStatus === PremiumStatus.CHARGED || s.processingStatus === ProcessingStatus.PROCESSED)} 
          onUpdate={handleUpdateSale}
          type="retention"
        />
      );
      case 'financials': return <Financials state={state} onAddExpense={(e) => updateState('expenses', [e, ...state.expenses])} onDeleteExpense={(id) => updateState('expenses', state.expenses.filter(e => e.id !== id))} />;
      case 'hr': return <HRModule state={state} onUpdateState={updateState} user={user} />;
      case 'admin': return <AdminConsole state={state} onUpdateState={updateState} currentUser={user} />;
      case 'all-sales': return <SalesManagement title="Master Sales Ledger" sales={state.sales} onUpdate={() => {}} type="view" />;
      default: return <Dashboard state={state} user={user} />;
    }
  };

  return (
    <div className="flex h-screen bg-slate-50 font-sans text-slate-900 overflow-hidden">
      <aside className="w-64 bg-slate-900 text-white flex flex-col shadow-xl z-20">
        <div className="p-6 flex items-center gap-3 border-b border-slate-800">
          <div className="bg-blue-600 p-2 rounded-lg"><TrendingUp className="w-6 h-6" /></div>
          <span className="text-xl font-bold tracking-tight">RBS Tech</span>
        </div>
        
        <nav className="flex-1 px-4 py-6 space-y-1 overflow-y-auto custom-scrollbar">
          {allowedTabs.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group ${
                  activeTab === item.id ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/20' : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Icon className={`w-5 h-5 ${activeTab === item.id ? 'text-white' : 'text-slate-400 group-hover:text-blue-400'}`} />
                <span className="font-medium">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-6 border-t border-slate-800">
          <div className="bg-slate-800/50 p-3 rounded-xl flex items-center justify-between">
            <div className="flex items-center gap-3 overflow-hidden">
              <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center font-bold text-xs flex-shrink-0">
                {user.fullName.charAt(0)}
              </div>
              <div className="truncate">
                <p className="text-sm font-semibold truncate">{user.fullName}</p>
                <p className="text-xs text-slate-500 truncate">{user.role}</p>
              </div>
            </div>
            <button onClick={handleLogout} title="Logout" className="text-slate-500 hover:text-rose-400 ml-2 transition-colors"><LogOut className="w-4 h-4" /></button>
          </div>
        </div>
      </aside>

      <main className="flex-1 flex flex-col overflow-hidden">
        <header className="h-16 bg-white border-b border-slate-200 px-8 flex items-center justify-between z-10 shadow-sm shadow-slate-200/50">
          <div className="flex items-center gap-4 text-slate-400">
            <Search className="w-5 h-5" />
            <input type="text" placeholder="Quick Search CRM..." className="bg-transparent border-none outline-none text-sm w-64 focus:ring-0 placeholder:text-slate-400" />
          </div>
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-100 rounded-full">
              <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
              <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">Live System</span>
            </div>
            <button className="relative text-slate-400 hover:text-slate-600 transition-colors">
              <Bell className="w-6 h-6" /><span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
            </button>
            <button className="text-slate-400 hover:text-slate-600 transition-colors"><Settings className="w-6 h-6" /></button>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-8 bg-slate-50/50 custom-scrollbar">
          <div className="max-w-7xl mx-auto">{renderContent()}</div>
        </div>
      </main>
    </div>
  );
};

export default App;

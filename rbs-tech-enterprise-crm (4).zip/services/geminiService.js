
import { GoogleGenAI } from "@google/genai";

export async function getBusinessInsights(state) {
  const apiKey = (window.process && window.process.env && window.process.env.API_KEY) || "";
  if (!apiKey) {
    return "AI Insights require a valid API key.";
  }

  try {
    const ai = new GoogleGenAI({ apiKey: apiKey });
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: "Analyze the current CRM data and provide 3 brief actionable business insights for the owner based on performance stats."
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Unable to generate insights at this time.";
  }
}


import { GoogleGenAI } from "@google/genai";
import { CRMState } from "../types";

export async function getBusinessInsights(state: CRMState) {
  const summary = {
    totalSales: state.sales.length,
    approvedSales: state.sales.filter(s => s.qcStatus === 'Approved').length,
    totalRevenue: state.sales.filter(s => s.premiumStatus === 'Premium Charged').reduce((acc, s) => acc + (s.actualPremiumAmount || 0), 0),
    totalExpenses: state.expenses.reduce((acc, e) => acc + e.amount, 0),
    topBranch: Object.entries(
      state.sales.reduce((acc: any, s) => {
        acc[s.closerBranch] = (acc[s.closerBranch] || 0) + 1;
        return acc;
      }, {})
    ).sort((a: any, b: any) => b[1] - a[1])[0]?.[0] || 'N/A'
  };

  try {
    // Initialize GoogleGenAI inside the function to use the environment's API key at call time
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Analyze this Auto Warranty CRM data and provide 3 actionable business insights for the owner:
      - Total Sales: ${summary.totalSales}
      - Approved QC: ${summary.approvedSales}
      - Revenue: $${summary.totalRevenue}
      - Expenses: $${summary.totalExpenses}
      - Top Performing Branch: ${summary.topBranch}
      
      Keep it brief, professional, and data-driven.`
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Unable to generate insights at this time.";
  }
}

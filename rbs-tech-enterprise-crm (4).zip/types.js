export const UserRole = {
  DIRECTOR: 'Director',
  HR: 'HR',
  GENERAL_MANAGER: 'General Manager',
  MANAGER: 'Manager',
  SALES: 'Sales Agent'
};

export const QCStatus = {
  PENDING: 'Pending QC',
  APPROVED: 'Approved',
  REJECTED: 'Rejected',
  HOLD: 'Hold'
};

export const ProcessingStatus = {
  PENDING: 'Pending Processing',
  PROCESSED: 'Sales Processed',
  REJECTED: 'Sale Rejected',
  HOLD: 'Sale On Hold'
};

export const PremiumStatus = {
  PENDING: 'Awaiting Date',
  CHARGED: 'Premium Charged',
  DECLINED: 'Premium Declined'
};
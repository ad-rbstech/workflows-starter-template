
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://xvjrrpifiqmbvugmofzg.supabase.co';
const supabaseAnonKey = 'sb_publishable_VtazyudAE5UH85d6QHtD5Q_MsBSw3cO';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

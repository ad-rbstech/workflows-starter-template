
import React, { useState, useMemo } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Plus, 
  Trash2, 
  ArrowUpCircle, 
  ArrowDownCircle,
  PiggyBank
} from 'lucide-react';
import { CRMState, ExpenseRecord, PremiumStatus } from '../types';
import { EXPENSE_CATEGORIES } from '../constants';

interface Props {
  state: CRMState;
  onAddExpense: (e: ExpenseRecord) => void;
  onDeleteExpense: (id: string) => void;
}

const Financials: React.FC<Props> = ({ state, onAddExpense, onDeleteExpense }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [newExpense, setNewExpense] = useState<Partial<ExpenseRecord>>({
    category: 'Salaries + Bonus',
    date: new Date().toISOString().split('T')[0],
    amount: 0,
    notes: ''
  });

  const totals = useMemo(() => {
    const expenses = state.expenses.reduce((sum, e) => sum + e.amount, 0);
    const revenue = state.sales
      .filter(s => s.premiumStatus === PremiumStatus.CHARGED)
      .reduce((sum, s) => sum + (s.actualPremiumAmount || 0), 0);
    return {
      revenue,
      expenses,
      net: revenue - expenses
    };
  }, [state]);

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    onAddExpense({
      ...newExpense as ExpenseRecord,
      id: `EX-${Date.now()}`
    });
    setIsAdding(false);
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Financial Ledger</h2>
          <p className="text-slate-500">Comprehensive income and burn rate analysis.</p>
        </div>
        <button 
          onClick={() => setIsAdding(!isAdding)}
          className="flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 shadow-lg shadow-blue-500/20 transition-all"
        >
          {isAdding ? 'Cancel Entry' : <><Plus className="w-5 h-5" /> Add Expense</>}
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-white p-8 rounded-2xl shadow-sm border border-emerald-100 flex items-center gap-6">
          <div className="bg-emerald-100 text-emerald-600 p-4 rounded-2xl">
            <ArrowUpCircle className="w-8 h-8" />
          </div>
          <div>
            <p className="text-sm font-bold text-slate-400 uppercase tracking-wider">Total Income</p>
            <p className="text-3xl font-black text-slate-800">${totals.revenue.toLocaleString()}</p>
          </div>
        </div>

        <div className="bg-white p-8 rounded-2xl shadow-sm border border-rose-100 flex items-center gap-6">
          <div className="bg-rose-100 text-rose-600 p-4 rounded-2xl">
            <ArrowDownCircle className="w-8 h-8" />
          </div>
          <div>
            <p className="text-sm font-bold text-slate-400 uppercase tracking-wider">Total Expenses</p>
            <p className="text-3xl font-black text-slate-800">${totals.expenses.toLocaleString()}</p>
          </div>
        </div>

        <div className={`p-8 rounded-2xl shadow-sm border flex items-center gap-6 transition-colors ${totals.net >= 0 ? 'bg-blue-600 border-blue-500 text-white' : 'bg-rose-600 border-rose-500 text-white'}`}>
          <div className="bg-white/20 p-4 rounded-2xl">
            <PiggyBank className="w-8 h-8" />
          </div>
          <div>
            <p className="text-sm font-bold text-white/70 uppercase tracking-wider">Net Profit</p>
            <p className="text-3xl font-black">${totals.net.toLocaleString()}</p>
          </div>
        </div>
      </div>

      {isAdding && (
        <div className="bg-white p-8 rounded-2xl shadow-xl border border-blue-200 animate-fadeIn">
          <h3 className="text-lg font-bold mb-6 text-slate-800">Record New Business Expense</h3>
          <form onSubmit={handleAdd} className="grid grid-cols-1 md:grid-cols-4 gap-6 items-end">
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase">Category</label>
              <select 
                className="w-full p-3 rounded-xl border border-slate-200"
                value={newExpense.category}
                onChange={e => setNewExpense({...newExpense, category: e.target.value as any})}
              >
                {EXPENSE_CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase">Amount ($)</label>
              <input 
                type="number"
                required
                className="w-full p-3 rounded-xl border border-slate-200"
                placeholder="0.00"
                onChange={e => setNewExpense({...newExpense, amount: parseFloat(e.target.value)})}
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase">Date</label>
              <input 
                type="date"
                required
                className="w-full p-3 rounded-xl border border-slate-200"
                value={newExpense.date}
                onChange={e => setNewExpense({...newExpense, date: e.target.value})}
              />
            </div>
            <button className="py-3 bg-blue-600 text-white font-bold rounded-xl shadow-lg shadow-blue-500/20">
              Save Expense
            </button>
          </form>
        </div>
      )}

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="p-6 border-b border-slate-100">
          <h3 className="font-bold text-slate-800 uppercase tracking-widest text-xs">Expense Breakdown</h3>
        </div>
        <table className="w-full text-left">
          <thead>
            <tr className="bg-slate-50">
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Date</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Category</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Amount</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {state.expenses.length === 0 ? (
              <tr>
                <td colSpan={4} className="px-6 py-8 text-center text-slate-400 italic">No expenses recorded yet.</td>
              </tr>
            ) : state.expenses.map(exp => (
              <tr key={exp.id}>
                <td className="px-6 py-4 text-sm font-medium text-slate-600">{new Date(exp.date).toLocaleDateString()}</td>
                <td className="px-6 py-4 text-sm font-bold text-slate-800">{exp.category}</td>
                <td className="px-6 py-4 text-sm font-bold text-rose-600">-${exp.amount.toLocaleString()}</td>
                <td className="px-6 py-4 text-right">
                  <button 
                    onClick={() => onDeleteExpense(exp.id)}
                    className="p-2 text-slate-300 hover:text-rose-600 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Financials;


import React, { useState } from 'react';
import { User, CheckCircle2, ArrowRight, Car, CreditCard } from 'lucide-react';
import { QCStatus, ProcessingStatus, PremiumStatus } from '../types.js';
import { USA_STATES, CAR_MAKES, CAR_MODELS_MAP } from '../constants.js';

const SaleForm = ({ onSubmit, currentUser, branches }) => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    frontierBranch: branches[0] || 'RBS',
    closerBranch: currentUser.branch || branches[0] || 'RBS',
    closerName: currentUser.fullName,
    carYear: 2024,
    state: 'Alabama',
    qcStatus: QCStatus.PENDING,
    processingStatus: ProcessingStatus.PENDING,
    premiumStatus: PremiumStatus.PENDING,
    incomeUpdated: false,
    retentionCall1Done: false,
    retentionCall2Done: false,
    qcNotes: '',
    processingComments: ''
  });

  const handleChange = (e) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'number' ? parseFloat(value) : value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      id: `S-${Date.now()}`,
      createdAt: new Date().toISOString()
    });
  };

  return (
    <div className="max-w-4xl mx-auto bg-white rounded-3xl shadow-xl overflow-hidden border">
      <div className="p-8 bg-slate-900 text-white flex justify-between items-center">
        <h2 className="text-2xl font-bold">New Sale Entry</h2>
        <span className="text-slate-400">Step {step} of 3</span>
      </div>
      <form onSubmit={handleSubmit} className="p-8 space-y-6">
        {step === 1 && (
          <div className="space-y-4 animate-fadeIn">
            <input name="customerName" placeholder="Customer Name" required onChange={handleChange} className="w-full p-3 border rounded-xl" />
            <input name="customerNumber" placeholder="Phone Number" required onChange={handleChange} className="w-full p-3 border rounded-xl" />
            <select name="state" onChange={handleChange} className="w-full p-3 border rounded-xl">
              {USA_STATES.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
            <button type="button" onClick={() => setStep(2)} className="w-full bg-blue-600 text-white p-3 rounded-xl font-bold">Next Step</button>
          </div>
        )}
        {step === 2 && (
          <div className="space-y-4 animate-fadeIn">
            <select name="carMake" required onChange={handleChange} className="w-full p-3 border rounded-xl">
               <option value="">Select Make</option>
               {CAR_MAKES.map(m => <option key={m} value={m}>{m}</option>)}
            </select>
            <input name="mileage" type="number" placeholder="Mileage" required onChange={handleChange} className="w-full p-3 border rounded-xl" />
            <button type="button" onClick={() => setStep(3)} className="w-full bg-blue-600 text-white p-3 rounded-xl font-bold">Final Step</button>
          </div>
        )}
        {step === 3 && (
          <div className="space-y-4 animate-fadeIn">
            <input name="policyPrice" type="number" placeholder="Total Policy Price" required onChange={handleChange} className="w-full p-3 border rounded-xl" />
            <input name="monthlyPremium" type="number" placeholder="Monthly Premium" required onChange={handleChange} className="w-full p-3 border rounded-xl" />
            <button type="submit" className="w-full bg-emerald-600 text-white p-3 rounded-xl font-bold uppercase tracking-widest">Submit Sale</button>
          </div>
        )}
      </form>
    </div>
  );
};

export default SaleForm;

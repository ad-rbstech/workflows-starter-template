
import React, { useMemo } from 'react';
import { ArrowUpCircle, ArrowDownCircle, PiggyBank } from 'lucide-react';
import { PremiumStatus } from '../types.js';

const Financials = ({ state }) => {
  const totals = useMemo(() => {
    const expenses = state.expenses.reduce((sum, e) => sum + e.amount, 0);
    const revenue = state.sales
      .filter(s => s.premiumStatus === PremiumStatus.CHARGED)
      .reduce((sum, s) => sum + (s.actualPremiumAmount || 0), 0);
    return { revenue, expenses, net: revenue - expenses };
  }, [state]);

  return (
    <div className="space-y-8">
      <h2 className="text-2xl font-bold">Financial Ledger</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-8 rounded-3xl border border-emerald-100">
           <ArrowUpCircle className="text-emerald-500 w-8 h-8 mb-2" />
           <p className="text-sm font-bold text-slate-400 uppercase">Total Income</p>
           <p className="text-3xl font-black text-slate-800">${totals.revenue.toLocaleString()}</p>
        </div>
        <div className="bg-white p-8 rounded-3xl border border-rose-100">
           <ArrowDownCircle className="text-rose-500 w-8 h-8 mb-2" />
           <p className="text-sm font-bold text-slate-400 uppercase">Total Expenses</p>
           <p className="text-3xl font-black text-slate-800">${totals.expenses.toLocaleString()}</p>
        </div>
        <div className={`p-8 rounded-3xl text-white ${totals.net >= 0 ? 'bg-blue-600' : 'bg-rose-600'}`}>
           <PiggyBank className="w-8 h-8 mb-2" />
           <p className="text-sm font-bold opacity-70 uppercase">Net Profit</p>
           <p className="text-3xl font-black">${totals.net.toLocaleString()}</p>
        </div>
      </div>
    </div>
  );
};

export default Financials;

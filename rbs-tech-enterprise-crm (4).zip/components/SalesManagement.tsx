
import React, { useState } from 'react';
import { 
  Eye, 
  MessageSquare, 
  Calendar, 
  User, 
  Phone, 
  CheckCircle, 
  XCircle, 
  Clock,
  MoreVertical,
  ChevronDown,
  ArrowRightCircle,
  ShieldCheck,
  CreditCard,
  PhoneCall,
  Check
} from 'lucide-react';
import { SaleRecord, QCStatus, ProcessingStatus, PremiumStatus, Branch } from '../types';
import { CARRIERS } from '../constants';

interface Props {
  title: string;
  sales: SaleRecord[];
  onUpdate: (id: string, updates: Partial<SaleRecord>) => void;
  type: 'qc' | 'processing' | 'premium' | 'retention' | 'view';
}

const SalesManagement: React.FC<Props> = ({ title, sales, onUpdate, type }) => {
  const [selectedSale, setSelectedSale] = useState<SaleRecord | null>(null);

  const getStatusBadge = (status: string) => {
    const s = status.toLowerCase();
    if (s.includes('approved') || s.includes('processed') || s.includes('charged')) 
      return 'bg-emerald-50 text-emerald-700 border-emerald-100';
    if (s.includes('rejected') || s.includes('declined')) 
      return 'bg-rose-50 text-rose-700 border-rose-100';
    if (s.includes('hold')) 
      return 'bg-amber-50 text-amber-700 border-amber-100';
    return 'bg-slate-50 text-slate-700 border-slate-100';
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-slate-800">{title}</h2>
        <span className="bg-slate-200 text-slate-600 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">
          {sales.length} Active Records
        </span>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Sale Info</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Customer</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Branch</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Status</th>
                {type === 'retention' && <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Retention</th>}
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {sales.length === 0 ? (
                <tr>
                  <td colSpan={type === 'retention' ? 6 : 5} className="px-6 py-12 text-center text-slate-400 italic">No records found for this stage.</td>
                </tr>
              ) : sales.map(sale => (
                <tr key={sale.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-6 py-4">
                    <div className="flex flex-col">
                      <span className="font-bold text-slate-900">{sale.id}</span>
                      <span className="text-xs text-slate-500">{new Date(sale.createdAt).toLocaleDateString()}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center font-bold text-xs">
                        {sale.customerName.charAt(0)}
                      </div>
                      <div className="flex flex-col">
                        <span className="text-sm font-semibold text-slate-800">{sale.customerName}</span>
                        <span className="text-xs text-slate-500">{sale.carYear} {sale.carMake}</span>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm font-medium text-slate-600">{sale.closerBranch}</span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-col gap-1">
                      <span className={`px-2 py-1 rounded-full text-[10px] w-fit font-bold border ${getStatusBadge(sale.qcStatus)}`}>
                        QC: {sale.qcStatus}
                      </span>
                      <span className={`px-2 py-1 rounded-full text-[10px] w-fit font-bold border ${getStatusBadge(sale.processingStatus)}`}>
                        PR: {sale.processingStatus}
                      </span>
                    </div>
                  </td>
                  {type === 'retention' && (
                    <td className="px-6 py-4">
                      <div className="flex gap-2">
                        <div className={`w-3 h-3 rounded-full ${sale.retentionCall1Done ? 'bg-emerald-500' : 'bg-slate-200'}`} title="7-10 Day Call"></div>
                        <div className={`w-3 h-3 rounded-full ${sale.retentionCall2Done ? 'bg-emerald-500' : 'bg-slate-200'}`} title="Pre-Premium Call"></div>
                      </div>
                    </td>
                  )}
                  <td className="px-6 py-4 text-right">
                    <button 
                      onClick={() => setSelectedSale(sale)}
                      className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all"
                    >
                      <ArrowRightCircle className="w-5 h-5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Action Drawer/Modal */}
      {selectedSale && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex justify-end">
          <div className="w-full max-w-xl bg-white h-full shadow-2xl flex flex-col animate-slideLeft">
            <div className="p-6 bg-slate-900 text-white flex justify-between items-center">
              <div>
                <h3 className="text-xl font-bold">Manage Case: {selectedSale.id}</h3>
                <p className="text-sm text-slate-400">Customer: {selectedSale.customerName} ({selectedSale.customerNumber})</p>
              </div>
              <button onClick={() => setSelectedSale(null)} className="p-2 hover:bg-white/10 rounded-lg transition-colors">
                <XCircle className="w-6 h-6" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-8 space-y-8 custom-scrollbar">
              {/* Step 2: Quality Check */}
              <section className="space-y-4">
                <h4 className="font-bold text-slate-800 flex items-center gap-2"><ShieldCheck className="w-5 h-5 text-blue-500" /> Step 2: Quality Check</h4>
                <div className="grid grid-cols-2 gap-4">
                  {[QCStatus.APPROVED, QCStatus.REJECTED, QCStatus.HOLD].map(s => (
                    <button
                      key={s}
                      onClick={() => {
                        onUpdate(selectedSale.id, { qcStatus: s });
                        setSelectedSale({...selectedSale, qcStatus: s});
                      }}
                      className={`px-4 py-2 rounded-xl text-sm font-bold border-2 transition-all ${
                        selectedSale.qcStatus === s ? 'bg-blue-600 border-blue-600 text-white' : 'border-slate-100 hover:border-blue-200 text-slate-500'
                      }`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
                <textarea 
                  className="w-full p-4 rounded-xl border border-slate-200 bg-slate-50 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                  placeholder="QC Notes Box"
                  rows={2}
                  value={selectedSale.qcNotes}
                  onChange={(e) => onUpdate(selectedSale.id, { qcNotes: e.target.value })}
                />
              </section>

              {/* Step 3: Sale Processing */}
              {selectedSale.qcStatus === QCStatus.APPROVED && (
                <section className="space-y-4 animate-fadeIn">
                  <h4 className="font-bold text-slate-800 flex items-center gap-2"><Clock className="w-5 h-5 text-amber-500" /> Step 3: Sale Processing</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-400 uppercase">Processed Carrier</label>
                      <select 
                        className="w-full p-3 rounded-xl border border-slate-200"
                        value={selectedSale.carrier || ''}
                        onChange={(e) => onUpdate(selectedSale.id, { carrier: e.target.value })}
                      >
                        <option value="">Select Carrier</option>
                        {CARRIERS.map(c => <option key={c} value={c}>{c}</option>)}
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-400 uppercase">Status</label>
                      <select 
                        className="w-full p-3 rounded-xl border border-slate-200"
                        value={selectedSale.processingStatus}
                        onChange={(e) => {
                          onUpdate(selectedSale.id, { processingStatus: e.target.value as ProcessingStatus });
                          setSelectedSale({...selectedSale, processingStatus: e.target.value as ProcessingStatus});
                        }}
                      >
                        {Object.values(ProcessingStatus).map(ps => <option key={ps} value={ps}>{ps}</option>)}
                      </select>
                    </div>
                  </div>
                  <textarea 
                    className="w-full p-4 rounded-xl border border-slate-200 bg-slate-50 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                    placeholder="Comment BOX"
                    rows={2}
                    value={selectedSale.processingComments}
                    onChange={(e) => onUpdate(selectedSale.id, { processingComments: e.target.value })}
                  />
                </section>
              )}

              {/* Step 4 & 5: Premium Tracking */}
              {selectedSale.processingStatus === ProcessingStatus.PROCESSED && (
                <section className="space-y-4 animate-fadeIn">
                  <h4 className="font-bold text-slate-800 flex items-center gap-2"><CreditCard className="w-5 h-5 text-emerald-500" /> Step 4 & 5: Premium Updates</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-400 uppercase">Premium Due Date</label>
                      <input 
                        type="date"
                        className="w-full p-3 rounded-xl border border-slate-200"
                        value={selectedSale.premiumDueDate || ''}
                        onChange={(e) => onUpdate(selectedSale.id, { premiumDueDate: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-400 uppercase">Premium Amount ($)</label>
                      <input 
                        type="number"
                        className="w-full p-3 rounded-xl border border-slate-200"
                        placeholder="0.00"
                        value={selectedSale.actualPremiumAmount || ''}
                        onChange={(e) => onUpdate(selectedSale.id, { actualPremiumAmount: parseFloat(e.target.value) })}
                      />
                    </div>
                  </div>
                  <div className="flex gap-4">
                    {[PremiumStatus.CHARGED, PremiumStatus.DECLINED].map(ps => (
                      <button
                        key={ps}
                        onClick={() => {
                          onUpdate(selectedSale.id, { premiumStatus: ps, incomeUpdated: ps === PremiumStatus.CHARGED });
                          setSelectedSale({...selectedSale, premiumStatus: ps});
                        }}
                        className={`flex-1 px-4 py-2 rounded-xl text-sm font-bold border-2 transition-all ${
                          selectedSale.premiumStatus === ps ? 'bg-emerald-600 border-emerald-600 text-white' : 'border-slate-100 hover:border-emerald-200 text-slate-500'
                        }`}
                      >
                        {ps}
                      </button>
                    ))}
                  </div>
                  {selectedSale.premiumStatus === PremiumStatus.DECLINED && (
                    <textarea 
                      className="w-full p-4 rounded-xl border border-rose-200 bg-rose-50 text-sm outline-none"
                      placeholder="Declined reason comment box..."
                      rows={2}
                      value={selectedSale.declinedReason}
                      onChange={(e) => onUpdate(selectedSale.id, { declinedReason: e.target.value })}
                    />
                  )}
                </section>
              )}

              {/* Step 6: Retention */}
              {(selectedSale.premiumStatus === PremiumStatus.CHARGED || selectedSale.processingStatus === ProcessingStatus.PROCESSED) && (
                <section className="space-y-4 animate-fadeIn pb-8">
                  <h4 className="font-bold text-slate-800 flex items-center gap-2"><PhoneCall className="w-5 h-5 text-indigo-500" /> Step 6: Retention</h4>
                  <div className="space-y-3">
                    <button 
                      onClick={() => {
                        const val = !selectedSale.retentionCall1Done;
                        onUpdate(selectedSale.id, { retentionCall1Done: val });
                        setSelectedSale({...selectedSale, retentionCall1Done: val});
                      }}
                      className={`w-full flex items-center justify-between p-4 rounded-xl border transition-all ${selectedSale.retentionCall1Done ? 'bg-indigo-50 border-indigo-200 text-indigo-700' : 'bg-slate-50 border-slate-200 text-slate-600'}`}
                    >
                      <span className="text-sm font-bold text-left">Customer Services Call (7-10 Days)</span>
                      {selectedSale.retentionCall1Done ? <CheckCircle className="w-5 h-5" /> : <div className="w-5 h-5 rounded-full border-2 border-slate-300"></div>}
                    </button>
                    <button 
                      onClick={() => {
                        const val = !selectedSale.retentionCall2Done;
                        onUpdate(selectedSale.id, { retentionCall2Done: val });
                        setSelectedSale({...selectedSale, retentionCall2Done: val});
                      }}
                      className={`w-full flex items-center justify-between p-4 rounded-xl border transition-all ${selectedSale.retentionCall2Done ? 'bg-indigo-50 border-indigo-200 text-indigo-700' : 'bg-slate-50 border-slate-200 text-slate-600'}`}
                    >
                      <span className="text-sm font-bold text-left">Another Call (Before Premium Due Date)</span>
                      {selectedSale.retentionCall2Done ? <CheckCircle className="w-5 h-5" /> : <div className="w-5 h-5 rounded-full border-2 border-slate-300"></div>}
                    </button>
                  </div>
                </section>
              )}
            </div>

            <div className="p-6 border-t border-slate-100 bg-slate-50 flex gap-4">
              <button 
                onClick={() => setSelectedSale(null)}
                className="flex-1 py-3 bg-white border border-slate-200 text-slate-600 font-bold rounded-xl hover:bg-slate-100 transition-colors"
              >
                Close Case View
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SalesManagement;

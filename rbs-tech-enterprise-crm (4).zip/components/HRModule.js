
import React from 'react';
import { Calendar, UserRole } from '../types.js';

const HRModule = ({ state, user }) => {
  if (user.role !== 'Director' && user.role !== 'HR') return <div className="p-10 text-center">Access Restricted</div>;
  
  return (
    <div className="space-y-6">
       <h2 className="text-2xl font-bold">HR Management</h2>
       <div className="bg-white rounded-2xl border p-8">
          <p className="text-slate-500 italic text-sm">Attendance and Payroll monitoring active.</p>
       </div>
    </div>
  );
};

export default HRModule;

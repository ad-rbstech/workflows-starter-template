
import React, { useMemo, useState } from 'react';
import { 
  TrendingUp, 
  Users, 
  CheckCircle2, 
  ArrowUpRight, 
  ArrowDownRight, 
  Wallet, 
  Sparkles, 
  Filter, 
  Calendar,
  PhoneCall,
  DollarSign,
  PieChart as PieIcon,
  BarChart3
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { CRMState, PremiumStatus, User, UserRole, QCStatus } from '../types';

const Dashboard: React.FC<{ state: CRMState, user: User }> = ({ state, user }) => {
  const [filterBranch, setFilterBranch] = useState<string>('All');
  const [filterTime, setFilterTime] = useState<string>('All Time');

  const filteredSales = useMemo(() => {
    let sales = state.sales;
    if (filterBranch !== 'All') sales = sales.filter(s => s.closerBranch === filterBranch);
    return sales;
  }, [state.sales, filterBranch]);

  const stats = useMemo(() => {
    const total = filteredSales.length;
    const approved = filteredSales.filter(s => s.qcStatus === QCStatus.APPROVED).length;
    const rejected = filteredSales.filter(s => s.qcStatus === QCStatus.REJECTED).length;
    const charged = filteredSales.filter(s => s.premiumStatus === PremiumStatus.CHARGED);
    const revenue = charged.reduce((acc, s) => acc + (s.actualPremiumAmount || 0), 0);
    const expenses = state.expenses.reduce((acc, e) => acc + e.amount, 0);

    const retention1 = filteredSales.filter(s => s.retentionCall1Done).length;
    const retention2 = filteredSales.filter(s => s.retentionCall2Done).length;

    return {
      total,
      approved,
      rejected,
      revenue,
      expenses,
      net: revenue - expenses,
      approvalRate: total > 0 ? ((approved / total) * 100).toFixed(1) : '0',
      retentionRate: total > 0 ? (((retention1 + retention2) / (total * 2)) * 100).toFixed(1) : '0',
      chargedCount: charged.length
    };
  }, [filteredSales, state.expenses]);

  const agentStats = useMemo(() => {
    const map: Record<string, { sales: number, approved: number, commission: number }> = {};
    filteredSales.forEach(s => {
      if (!map[s.closerName]) map[s.closerName] = { sales: 0, approved: 0, commission: 0 };
      map[s.closerName].sales++;
      if (s.qcStatus === QCStatus.APPROVED) map[s.closerName].approved++;
      if (s.premiumStatus === PremiumStatus.CHARGED) map[s.closerName].commission += 50;
    });
    return Object.entries(map).map(([name, data]) => ({ name, ...data }));
  }, [filteredSales]);

  const branchData = useMemo(() => {
    const branches: Record<string, number> = {};
    filteredSales.forEach(s => { branches[s.closerBranch] = (branches[s.closerBranch] || 0) + 1; });
    return Object.entries(branches).map(([name, value]) => ({ name, value }));
  }, [filteredSales]);

  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

  // Executive view includes Director, GM, and Manager (Owners/Decision Makers)
  const isExecutive = [UserRole.DIRECTOR, UserRole.GENERAL_MANAGER, UserRole.MANAGER].includes(user.role);

  return (
    <div className="space-y-8 pb-12">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 tracking-tight">Management Dashboard</h1>
          <p className="text-slate-500">Business performance metrics and workflow tracking.</p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 bg-white border border-slate-200 rounded-xl px-4 py-2.5 shadow-sm text-sm">
            <Filter className="w-4 h-4 text-slate-400" />
            <select value={filterBranch} onChange={(e) => setFilterBranch(e.target.value)} className="bg-transparent outline-none font-medium text-slate-700 cursor-pointer">
              <option value="All">All Branches</option>
              {state.branches.map(b => <option key={b} value={b}>{b}</option>)}
            </select>
          </div>
          <div className="flex items-center gap-2 bg-white border border-slate-200 rounded-xl px-4 py-2.5 shadow-sm text-sm">
            <Calendar className="w-4 h-4 text-slate-400" />
            <select value={filterTime} onChange={(e) => setFilterTime(e.target.value)} className="bg-transparent outline-none font-medium text-slate-700 cursor-pointer">
              <option value="All Time">All Time</option>
              <option value="Today">Today</option>
              <option value="Week">This Week</option>
              <option value="Month">This Month</option>
            </select>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Gross Sales', val: stats.total, color: 'blue', icon: TrendingUp },
          { label: 'QC Approval', val: `${stats.approvalRate}%`, color: 'emerald', icon: CheckCircle2 },
          { label: 'Charged Premiums', val: stats.chargedCount, color: 'indigo', icon: DollarSign },
          { label: 'Retention Score', val: `${stats.retentionRate}%`, color: 'amber', icon: PhoneCall },
        ].map((kpi, idx) => (
          <div key={idx} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 hover:border-blue-200 hover:shadow-md transition-all">
            <div className={`p-3 bg-${kpi.color}-50 text-${kpi.color}-600 rounded-xl w-fit mb-4`}>
              <kpi.icon className="w-6 h-6" />
            </div>
            <h3 className="text-slate-500 text-xs font-bold uppercase tracking-wider">{kpi.label}</h3>
            <p className="text-2xl font-black text-slate-800 mt-1">{kpi.val}</p>
          </div>
        ))}
      </div>

      {isExecutive && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 animate-fadeIn">
          <div className="bg-slate-900 p-8 rounded-3xl text-white shadow-xl flex items-center justify-between border border-slate-800">
            <div>
              <p className="text-slate-400 text-xs font-bold uppercase tracking-widest mb-1">Total Revenue</p>
              <h4 className="text-3xl font-black text-emerald-400">${stats.revenue.toLocaleString()}</h4>
            </div>
            <div className="bg-emerald-500/10 p-3 rounded-2xl">
              <ArrowUpRight className="w-8 h-8 text-emerald-400" />
            </div>
          </div>
          <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm flex items-center justify-between">
            <div>
              <p className="text-slate-500 text-xs font-bold uppercase tracking-widest mb-1">Total Expenses</p>
              <h4 className="text-3xl font-black text-rose-500">${stats.expenses.toLocaleString()}</h4>
            </div>
            <div className="bg-rose-50 p-3 rounded-2xl">
              <ArrowDownRight className="w-8 h-8 text-rose-500" />
            </div>
          </div>
          <div className={`p-8 rounded-3xl shadow-sm flex items-center justify-between transition-colors border ${stats.net >= 0 ? 'bg-blue-600 border-blue-500 text-white shadow-blue-500/20' : 'bg-rose-600 border-rose-500 text-white shadow-rose-500/20'}`}>
            <div>
              <p className="text-white/70 text-xs font-bold uppercase tracking-widest mb-1">Net Business Result</p>
              <h4 className="text-3xl font-black">${stats.net.toLocaleString()}</h4>
            </div>
            <div className="bg-white/20 p-3 rounded-2xl">
              <Wallet className="w-8 h-8 text-white" />
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
          <div className="flex justify-between items-center mb-8">
            <h3 className="text-lg font-bold flex items-center gap-2 text-slate-800"><BarChart3 className="w-5 h-5 text-blue-500" /> Branch Productivity</h3>
            <span className="text-xs text-slate-400 font-bold uppercase tracking-widest">Efficiency Metrics</span>
          </div>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={branchData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 11}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 11}} />
                <Tooltip cursor={{fill: '#f8fafc'}} contentStyle={{borderRadius: '16px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)'}} />
                <Bar dataKey="value" fill="#3b82f6" radius={[8, 8, 0, 0]} barSize={45} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm flex flex-col">
          <div className="flex justify-between items-center mb-8">
            <h3 className="text-lg font-bold flex items-center gap-2 text-slate-800"><PieIcon className="w-5 h-5 text-emerald-500" /> Conversion Funnel</h3>
          </div>
          <div className="flex-1 min-h-[250px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={[
                  { name: 'Approved', value: stats.approved },
                  { name: 'Rejected', value: stats.rejected },
                  { name: 'Pending', value: Math.max(0, stats.total - (stats.approved + stats.rejected)) }
                ]} cx="50%" cy="50%" innerRadius={70} outerRadius={95} paddingAngle={8} dataKey="value">
                  <Cell fill="#10b981" />
                  <Cell fill="#ef4444" />
                  <Cell fill="#3b82f6" />
                </Pie>
                <Tooltip contentStyle={{borderRadius: '12px'}} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-6 space-y-3">
            <div className="flex justify-between items-center p-3 bg-emerald-50 rounded-xl border border-emerald-100">
              <span className="text-sm font-bold text-emerald-700">Approved Cases</span>
              <span className="text-sm font-black text-emerald-800">{stats.approved}</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-rose-50 rounded-xl border border-rose-100">
              <span className="text-sm font-bold text-rose-700">Rejected Cases</span>
              <span className="text-sm font-black text-rose-800">{stats.rejected}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden mb-12">
        <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
          <h3 className="font-bold text-slate-800 flex items-center gap-2"><Users className="w-5 h-5 text-blue-500" /> Top Performing Agents</h3>
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Commission: $50 / Sale</span>
        </div>
        <table className="w-full text-left">
          <thead className="bg-slate-50/50 text-xs font-bold text-slate-500 uppercase tracking-widest">
            <tr>
              <th className="px-8 py-5">Agent Identity</th>
              <th className="px-6 py-5">Gross Sales</th>
              <th className="px-6 py-5">QC Approved</th>
              <th className="px-8 py-5 text-right">Accrued Commission</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {agentStats.length === 0 ? (
              <tr>
                <td colSpan={4} className="px-8 py-12 text-center text-slate-400 italic">No agent data recorded yet.</td>
              </tr>
            ) : agentStats.sort((a, b) => b.approved - a.approved).map(agent => (
              <tr key={agent.name} className="text-sm hover:bg-blue-50/30 transition-colors group">
                <td className="px-8 py-5">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center font-bold text-slate-500 group-hover:bg-blue-100 group-hover:text-blue-600 transition-colors shadow-inner">
                      {agent.name.charAt(0)}
                    </div>
                    <span className="font-bold text-slate-800">{agent.name}</span>
                  </div>
                </td>
                <td className="px-6 py-5 font-medium text-slate-600">{agent.sales}</td>
                <td className="px-6 py-5">
                  <span className="px-3 py-1 bg-emerald-50 text-emerald-600 rounded-lg text-xs font-bold border border-emerald-100">{agent.approved}</span>
                </td>
                <td className="px-8 py-5 text-right">
                  <span className="text-emerald-600 font-black text-lg">${agent.commission.toLocaleString()}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Dashboard;


import React, { useState, useMemo } from 'react';
import { Calendar, UserCheck, DollarSign, Search, Plus, Filter, ShieldAlert } from 'lucide-react';
import { CRMState, AttendanceRecord, User, UserRole, Branch } from '../types';

const HRModule: React.FC<{ state: CRMState, onUpdateState: (k: keyof CRMState, v: any) => void, user: User }> = ({ state, onUpdateState, user }) => {
  const [activeSubTab, setActiveSubTab] = useState<'attendance' | 'payroll'>('attendance');
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);

  // Redundant but safe role check
  const isAuthorized = [UserRole.DIRECTOR, UserRole.HR].includes(user.role);

  if (!isAuthorized) {
    return (
      <div className="flex flex-col items-center justify-center p-12 bg-white rounded-3xl border border-rose-100 shadow-sm text-center">
        <ShieldAlert className="w-12 h-12 text-rose-500 mb-4" />
        <h3 className="text-xl font-bold text-slate-800">HR Access Denied</h3>
        <p className="text-slate-500 mt-2">Only HR Managers and Directors are authorized to view or edit personnel records.</p>
      </div>
    );
  }

  const markAttendance = (userId: string, status: 'Present' | 'Absent' | 'Late' | 'Leave') => {
    const newRecord: AttendanceRecord = {
      id: `ATT-${Date.now()}-${userId}`,
      userId,
      date: selectedDate,
      status
    };
    const existingIndex = state.attendance.findIndex(a => a.userId === userId && a.date === selectedDate);
    if (existingIndex > -1) {
      const updated = [...state.attendance];
      updated[existingIndex] = newRecord;
      onUpdateState('attendance', updated);
    } else {
      onUpdateState('attendance', [...state.attendance, newRecord]);
    }
  };

  const getAttendanceStatus = (userId: string) => {
    return state.attendance.find(a => a.userId === userId && a.date === selectedDate)?.status || 'Not Marked';
  };

  const payrollData = useMemo(() => {
    return state.users.map(u => {
      const commissions = state.sales.filter(s => s.closerName === u.fullName && s.premiumStatus === 'Premium Charged').length * 50;
      return {
        ...u,
        bonuses: commissions,
        netPay: u.baseSalary + commissions
      };
    });
  }, [state.users, state.sales]);

  return (
    <div className="space-y-8 pb-12">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-800 tracking-tight">Human Resources</h2>
          <p className="text-slate-500">Employee lifecycle, attendance and payroll management.</p>
        </div>
        <div className="flex bg-slate-100 p-1.5 rounded-xl shadow-inner">
          <button 
            onClick={() => setActiveSubTab('attendance')} 
            className={`px-6 py-2 rounded-lg text-sm font-bold transition-all ${activeSubTab === 'attendance' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-500 hover:text-slate-700'}`}
          >
            Attendance
          </button>
          <button 
            onClick={() => setActiveSubTab('payroll')} 
            className={`px-6 py-2 rounded-lg text-sm font-bold transition-all ${activeSubTab === 'payroll' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-500 hover:text-slate-700'}`}
          >
            Payroll
          </button>
        </div>
      </div>

      {activeSubTab === 'attendance' ? (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 bg-white border border-slate-200 rounded-xl px-4 py-2 shadow-sm">
                <Calendar className="w-4 h-4 text-slate-400" />
                <input 
                  type="date" 
                  value={selectedDate} 
                  onChange={(e) => setSelectedDate(e.target.value)} 
                  className="bg-transparent text-sm outline-none font-bold text-slate-700 cursor-pointer" 
                />
              </div>
            </div>
            <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Marking: {new Date(selectedDate).toDateString()}</div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-50/80 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                <tr>
                  <th className="px-8 py-4">Employee</th>
                  <th className="px-6 py-4">Role</th>
                  <th className="px-6 py-4">Branch</th>
                  <th className="px-6 py-4">Current Status</th>
                  <th className="px-8 py-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {state.users.map(emp => (
                  <tr key={emp.id} className="text-sm hover:bg-slate-50/50 transition-colors">
                    <td className="px-8 py-5 font-bold text-slate-800">{emp.fullName}</td>
                    <td className="px-6 py-5 text-slate-500 font-medium">{emp.role}</td>
                    <td className="px-6 py-5 font-bold text-slate-700">{emp.branch}</td>
                    <td className="px-6 py-5">
                      <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase border ${
                        getAttendanceStatus(emp.id) === 'Present' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 
                        getAttendanceStatus(emp.id) === 'Absent' ? 'bg-rose-50 text-rose-600 border-rose-100' : 
                        getAttendanceStatus(emp.id) === 'Late' ? 'bg-amber-50 text-amber-600 border-amber-100' :
                        'bg-slate-50 text-slate-400 border-slate-100'
                      }`}>
                        {getAttendanceStatus(emp.id)}
                      </span>
                    </td>
                    <td className="px-8 py-5 text-right space-x-1">
                      <button 
                        onClick={() => markAttendance(emp.id, 'Present')} 
                        className="text-[10px] font-black bg-emerald-50 text-emerald-600 hover:bg-emerald-600 hover:text-white px-3 py-1.5 rounded-lg transition-all border border-emerald-100 uppercase"
                      >
                        P
                      </button>
                      <button 
                        onClick={() => markAttendance(emp.id, 'Absent')} 
                        className="text-[10px] font-black bg-rose-50 text-rose-600 hover:bg-rose-600 hover:text-white px-3 py-1.5 rounded-lg transition-all border border-rose-100 uppercase"
                      >
                        A
                      </button>
                      <button 
                        onClick={() => markAttendance(emp.id, 'Late')} 
                        className="text-[10px] font-black bg-amber-50 text-amber-600 hover:bg-amber-600 hover:text-white px-3 py-1.5 rounded-lg transition-all border border-amber-100 uppercase"
                      >
                        L
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
            <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Automated Salary & Bonus Calculation</h3>
            <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white text-xs font-bold rounded-xl shadow-lg shadow-blue-500/20 hover:bg-blue-700 transition-all">
               Generate Payroll Report
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-50/80 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                <tr>
                  <th className="px-8 py-4">Employee</th>
                  <th className="px-6 py-4">Base Salary</th>
                  <th className="px-6 py-4">Bonuses (Commissions)</th>
                  <th className="px-6 py-4">Net Monthly Pay</th>
                  <th className="px-8 py-4 text-right">Payment Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {payrollData.map(p => (
                  <tr key={p.id} className="text-sm hover:bg-slate-50/50 transition-colors">
                    <td className="px-8 py-5">
                      <div className="flex flex-col">
                        <span className="font-bold text-slate-800">{p.fullName}</span>
                        <span className="text-[10px] text-slate-400 font-bold uppercase">{p.role}</span>
                      </div>
                    </td>
                    <td className="px-6 py-5 text-slate-600 font-medium">${p.baseSalary.toLocaleString()}</td>
                    <td className="px-6 py-5 text-emerald-600 font-black">
                      <div className="flex items-center gap-1">
                        <Plus className="w-3 h-3" /> ${p.bonuses.toLocaleString()}
                      </div>
                    </td>
                    <td className="px-6 py-5">
                      <span className="text-lg font-black text-slate-900">${p.netPay.toLocaleString()}</span>
                    </td>
                    <td className="px-8 py-5 text-right">
                      <span className="px-3 py-1 bg-blue-50 text-blue-600 rounded-full text-[10px] font-black uppercase border border-blue-100 tracking-wider">
                        Ready
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default HRModule;

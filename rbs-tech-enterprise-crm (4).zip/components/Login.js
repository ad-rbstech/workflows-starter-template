
import React, { useState } from 'react';
import { Shield, Lock, User as UserIcon } from 'lucide-react';
import { UserRole } from '../types.js';

const Login = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = (e) => {
    e.preventDefault();
    if (username === 'Addie.RBS' && password === 'RBS2580') {
      onLogin({
        id: '1', username: 'Addie.RBS', role: UserRole.DIRECTOR,
        branch: 'RBS', fullName: 'Addie RBS', baseSalary: 10000
      });
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-6 font-sans">
      <form onSubmit={handleLogin} className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-10 space-y-6">
        <div className="text-center space-y-2">
           <Shield className="w-12 h-12 text-blue-500 mx-auto" />
           <h1 className="text-2xl font-bold text-white">RBS Tech CRM</h1>
        </div>
        <input placeholder="Username" className="w-full bg-slate-950 border border-slate-800 p-4 rounded-xl text-white" value={username} onChange={e => setUsername(e.target.value)} />
        <input type="password" placeholder="Password" className="w-full bg-slate-950 border border-slate-800 p-4 rounded-xl text-white" value={password} onChange={e => setPassword(e.target.value)} />
        <button className="w-full bg-blue-600 text-white font-bold p-4 rounded-xl shadow-lg shadow-blue-500/20">Sign In</button>
      </form>
    </div>
  );
};

export default Login;


import React, { useState } from 'react';
import { Shield, Lock, User as UserIcon } from 'lucide-react';
import { User, UserRole, Branch } from '../types';

const Login: React.FC<{ onLogin: (u: User) => void }> = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Default Director Credentials as requested
    if (username === 'Addie.RBS' && password === 'RBS2580') {
      onLogin({
        id: '1',
        username: 'Addie.RBS',
        role: UserRole.DIRECTOR,
        // Fix: 'Branch' is a type alias for string, so we must use a string literal
        branch: 'RBS',
        fullName: 'Addie RBS',
        baseSalary: 10000
      });
      return;
    }

    // Mock other logins from potential localStorage state
    const savedState = localStorage.getItem('autoshield_crm_data_v2');
    if (savedState) {
      const data = JSON.parse(savedState);
      const found = data.users?.find((u: User) => u.username === username && u.password === password);
      if (found) {
        onLogin(found);
        return;
      }
    }

    setError('Invalid username or password');
  };

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-6">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-10 shadow-2xl">
        <div className="flex flex-col items-center mb-10">
          <div className="bg-blue-600 p-4 rounded-2xl mb-4 shadow-lg shadow-blue-500/20">
            <Shield className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-white tracking-tight">RBS Tech CRM</h1>
          <p className="text-slate-500 text-sm mt-1">Authorized Personnel Only</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-widest ml-1">Username</label>
            <div className="relative">
              <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-600" />
              <input 
                type="text" 
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-2xl pl-12 pr-4 py-4 text-white focus:border-blue-500 outline-none transition-all placeholder:text-slate-700" 
                placeholder="Enter username..." 
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-widest ml-1">Password</label>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-600" />
              <input 
                type="password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-2xl pl-12 pr-4 py-4 text-white focus:border-blue-500 outline-none transition-all placeholder:text-slate-700" 
                placeholder="Enter password..." 
                required
              />
            </div>
          </div>

          {error && <p className="text-rose-500 text-sm font-medium text-center">{error}</p>}

          <button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-2xl shadow-lg shadow-blue-500/10 transition-all flex items-center justify-center gap-2">
            Sign In to Dashboard
          </button>
        </form>

        <div className="mt-8 text-center">
          <p className="text-slate-600 text-xs">v2.0 Enterprise Cloud Deployment</p>
        </div>
      </div>
    </div>
  );
};

export default Login;

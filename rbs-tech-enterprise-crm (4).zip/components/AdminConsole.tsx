
import React, { useState } from 'react';
import { 
  UserPlus, 
  Building, 
  Trash2, 
  Plus, 
  Home, 
  Edit2, 
  Check, 
  X, 
  AlertCircle, 
  ShieldCheck,
  Key,
  Lock
} from 'lucide-react';
import { CRMState, User, UserRole, Branch } from '../types';

interface AdminConsoleProps {
  state: CRMState;
  onUpdateState: (k: keyof CRMState, v: any) => void;
  currentUser: User;
}

const AdminConsole: React.FC<AdminConsoleProps> = ({ state, onUpdateState, currentUser }) => {
  const [showAddUser, setShowAddUser] = useState(false);
  const [newBranchName, setNewBranchName] = useState('');
  const [editingBranch, setEditingBranch] = useState<string | null>(null);
  const [editBranchValue, setEditBranchValue] = useState('');
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  
  // Password Reset State
  const [resettingPasswordUserId, setResettingPasswordUserId] = useState<string | null>(null);
  const [newPasswordValue, setNewPasswordValue] = useState('');

  const [newUser, setNewUser] = useState<Partial<User>>({
    role: UserRole.SALES,
    branch: state.branches[0] || 'RBS',
    baseSalary: 3000
  });

  const canManageBranches = [UserRole.DIRECTOR, UserRole.HR, UserRole.GENERAL_MANAGER].includes(currentUser.role);
  const canResetPasswords = [UserRole.DIRECTOR, UserRole.HR, UserRole.GENERAL_MANAGER].includes(currentUser.role);

  const validateUserForm = (): boolean => {
    const errors: Record<string, string> = {};
    if (!newUser.fullName?.trim()) errors.fullName = "Full Name is required";
    if (!newUser.username?.trim()) errors.username = "Username is required";
    if (!newUser.password?.trim()) errors.password = "Password is required";
    if (!newUser.role) errors.role = "Role is required";
    if (!newUser.branch) errors.branch = "Branch is required";
    if (newUser.baseSalary === undefined || newUser.baseSalary <= 0) {
      errors.baseSalary = "Base salary must be a positive number";
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleAddUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateUserForm()) return;

    const u: User = {
      ...newUser as User,
      id: `USR-${Date.now()}`
    };
    onUpdateState('users', [...state.users, u]);
    setShowAddUser(false);
    setNewUser({
      role: UserRole.SALES,
      branch: state.branches[0] || 'RBS',
      baseSalary: 3000
    });
    setFormErrors({});
  };

  const handleResetPassword = (userId: string) => {
    if (!canResetPasswords) return;
    if (!newPasswordValue.trim()) {
      alert("Please enter a valid password.");
      return;
    }

    const updatedUsers = state.users.map(u => 
      u.id === userId ? { ...u, password: newPasswordValue } : u
    );

    onUpdateState('users', updatedUsers);
    setResettingPasswordUserId(null);
    setNewPasswordValue('');
    alert("Password reset successfully.");
  };

  const handleAddBranch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!canManageBranches) return;
    const trimmedName = newBranchName.trim();
    if (trimmedName && !state.branches.includes(trimmedName)) {
      onUpdateState('branches', [...state.branches, trimmedName]);
      setNewBranchName('');
    }
  };

  const handleStartEdit = (branch: string) => {
    if (!canManageBranches || branch === 'RBS') return;
    setEditingBranch(branch);
    setEditBranchValue(branch);
  };

  const handleSaveEdit = () => {
    const newVal = editBranchValue.trim();
    if (!newVal || newVal === editingBranch) {
      setEditingBranch(null);
      return;
    }

    if (state.branches.includes(newVal)) {
      alert("A branch with this name already exists.");
      return;
    }

    const updatedBranches = state.branches.map(b => b === editingBranch ? newVal : b);
    const updatedUsers = state.users.map(u => u.branch === editingBranch ? { ...u, branch: newVal } : u);
    const updatedSales = state.sales.map(s => ({
      ...s,
      frontierBranch: s.frontierBranch === editingBranch ? newVal : s.frontierBranch,
      closerBranch: s.closerBranch === editingBranch ? newVal : s.closerBranch,
    }));

    onUpdateState('branches', updatedBranches);
    onUpdateState('users', updatedUsers);
    onUpdateState('sales', updatedSales);
    setEditingBranch(null);
  };

  const handleRemoveBranch = (branch: string) => {
    if (!canManageBranches || branch === 'RBS') {
      alert("RBS Head Office cannot be removed.");
      return;
    }
    const hasUsers = state.users.some(u => u.branch === branch);
    const hasSales = state.sales.some(s => s.closerBranch === branch || s.frontierBranch === branch);
    
    if (hasUsers || hasSales) {
      if (!confirm(`Branch "${branch}" has associated users or sales records. Removing it might cause data display issues. Are you sure you want to delete this branch?`)) {
        return;
      }
    }
    onUpdateState('branches', state.branches.filter(b => b !== branch));
  };

  const toggleAddUser = () => {
    setShowAddUser(!showAddUser);
    setFormErrors({});
  };

  return (
    <div className="space-y-8 pb-12">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Admin Console</h2>
          <p className="text-slate-500">System configuration, user management, and branch controls.</p>
        </div>
        <button 
          onClick={toggleAddUser} 
          className="flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-xl font-bold shadow-lg shadow-blue-500/10 transition-all hover:bg-blue-700"
        >
          <UserPlus className="w-5 h-5" /> {showAddUser ? 'Close Form' : 'Add User Account'}
        </button>
      </div>

      {showAddUser && (
        <div className="bg-white p-8 rounded-2xl border border-blue-100 shadow-xl animate-fadeIn">
          <div className="mb-6 flex items-center gap-2 text-blue-600">
            <ShieldCheck className="w-5 h-5" />
            <h3 className="text-lg font-bold">Register New Employee Account</h3>
          </div>
          <form onSubmit={handleAddUser} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase flex justify-between">
                Full Name
                {formErrors.fullName && <span className="text-rose-500 font-normal normal-case flex items-center gap-1"><AlertCircle className="w-3 h-3" /> {formErrors.fullName}</span>}
              </label>
              <input 
                onChange={e => setNewUser({...newUser, fullName: e.target.value})} 
                className={`w-full p-3 bg-slate-50 border rounded-xl outline-none focus:ring-2 transition-all ${formErrors.fullName ? 'border-rose-300 focus:ring-rose-200' : 'border-slate-200 focus:ring-blue-500'}`} 
                placeholder="John Agent" 
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase flex justify-between">
                Username
                {formErrors.username && <span className="text-rose-500 font-normal normal-case flex items-center gap-1"><AlertCircle className="w-3 h-3" /> {formErrors.username}</span>}
              </label>
              <input 
                onChange={e => setNewUser({...newUser, username: e.target.value})} 
                className={`w-full p-3 bg-slate-50 border rounded-xl outline-none focus:ring-2 transition-all ${formErrors.username ? 'border-rose-300 focus:ring-rose-200' : 'border-slate-200 focus:ring-blue-500'}`} 
                placeholder="john.rbs" 
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase flex justify-between">
                Password
                {formErrors.password && <span className="text-rose-500 font-normal normal-case flex items-center gap-1"><AlertCircle className="w-3 h-3" /> {formErrors.password}</span>}
              </label>
              <input 
                type="password" 
                onChange={e => setNewUser({...newUser, password: e.target.value})} 
                className={`w-full p-3 bg-slate-50 border rounded-xl outline-none focus:ring-2 transition-all ${formErrors.password ? 'border-rose-300 focus:ring-rose-200' : 'border-slate-200 focus:ring-blue-500'}`} 
                placeholder="••••••••"
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase">Role</label>
              <select 
                value={newUser.role}
                onChange={e => setNewUser({...newUser, role: e.target.value as UserRole})} 
                className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
              >
                {Object.values(UserRole).map(r => <option key={r} value={r}>{r}</option>)}
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase">Branch</label>
              <select 
                value={newUser.branch}
                onChange={e => setNewUser({...newUser, branch: e.target.value as Branch})} 
                className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
              >
                {state.branches.map(b => <option key={b} value={b}>{b}</option>)}
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase flex justify-between">
                Base Salary ($)
                {formErrors.baseSalary && <span className="text-rose-500 font-normal normal-case flex items-center gap-1"><AlertCircle className="w-3 h-3" /> {formErrors.baseSalary}</span>}
              </label>
              <input 
                type="number" 
                value={newUser.baseSalary}
                onChange={e => setNewUser({...newUser, baseSalary: parseInt(e.target.value)})} 
                className={`w-full p-3 bg-slate-50 border rounded-xl outline-none focus:ring-2 transition-all ${formErrors.baseSalary ? 'border-rose-300 focus:ring-rose-200' : 'border-slate-200 focus:ring-blue-500'}`} 
                placeholder="3000" 
              />
            </div>

            <div className="lg:col-span-3 flex justify-end gap-3 mt-4">
              <button 
                type="button" 
                onClick={toggleAddUser} 
                className="px-6 py-3 text-slate-500 font-bold hover:bg-slate-50 rounded-xl transition-all"
              >
                Cancel
              </button>
              <button className="px-10 py-3 bg-blue-600 text-white font-bold rounded-xl shadow-lg shadow-blue-500/10 hover:bg-blue-700 transition-all flex items-center gap-2">
                <Check className="w-5 h-5" /> Confirm & Create Account
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-slate-100 flex justify-between items-center">
            <h3 className="font-bold text-slate-800">System Users</h3>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">{state.users.length} Total Users</span>
          </div>
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-xs font-bold text-slate-500 uppercase">
              <tr>
                <th className="px-6 py-4">User</th>
                <th className="px-6 py-4">Role</th>
                <th className="px-6 py-4">Branch</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {state.users.map(u => (
                <tr key={u.id} className="text-sm group">
                  <td className="px-6 py-4">
                    <div className="flex flex-col">
                      <span className="font-bold text-slate-800">{u.fullName}</span>
                      <span className="text-xs text-slate-400">{u.username}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="px-2 py-1 bg-slate-100 rounded text-[10px] font-bold text-slate-600">{u.role}</span>
                  </td>
                  <td className="px-6 py-4 font-medium text-slate-500">{u.branch}</td>
                  <td className="px-6 py-4">
                    <div className="flex justify-end items-center gap-2">
                      {resettingPasswordUserId === u.id ? (
                        <div className="flex items-center gap-2 animate-fadeIn">
                          <div className="relative">
                            <Lock className="absolute left-2 top-1/2 -translate-y-1/2 w-3 h-3 text-slate-400" />
                            <input
                              autoFocus
                              type="password"
                              placeholder="New pass..."
                              className="w-32 pl-7 pr-2 py-1.5 bg-slate-50 border border-blue-500 rounded-lg text-xs outline-none"
                              value={newPasswordValue}
                              onChange={(e) => setNewPasswordValue(e.target.value)}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') handleResetPassword(u.id);
                                if (e.key === 'Escape') setResettingPasswordUserId(null);
                              }}
                            />
                          </div>
                          <button 
                            onClick={() => handleResetPassword(u.id)}
                            className="p-1.5 text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                          >
                            <Check className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={() => {
                              setResettingPasswordUserId(null);
                              setNewPasswordValue('');
                            }}
                            className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      ) : (
                        <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-all">
                          {canResetPasswords && (
                            <button 
                              title="Reset Password"
                              onClick={() => setResettingPasswordUserId(u.id)}
                              className="p-2 text-slate-400 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-colors"
                            >
                              <Key className="w-4 h-4" />
                            </button>
                          )}
                          <button 
                            onClick={() => {
                              if(confirm(`Are you sure you want to delete user ${u.fullName}?`)) {
                                onUpdateState('users', state.users.filter(x => x.id !== u.id));
                              }
                            }} 
                            className="p-2 text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-lg transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
              {state.users.length === 0 && (
                <tr>
                   <td colSpan={4} className="px-6 py-8 text-center text-slate-400 italic text-sm">No users registered yet.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="space-y-8">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-8 space-y-6 group">
            <h3 className="font-bold text-slate-800 flex items-center gap-2"><Building className="w-5 h-5 text-blue-500" /> Branch Management</h3>
            
            {canManageBranches ? (
              <>
                <form onSubmit={handleAddBranch} className="flex gap-2">
                  <input 
                    type="text" 
                    value={newBranchName}
                    onChange={e => setNewBranchName(e.target.value)}
                    placeholder="New Branch Name..."
                    className="flex-1 p-3 bg-slate-50 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <button type="submit" className="p-3 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors shadow-lg shadow-blue-500/20">
                    <Plus className="w-5 h-5" />
                  </button>
                </form>

                <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                  {state.branches.map(b => (
                    <div key={b} className="flex justify-between items-center p-4 bg-slate-50 rounded-2xl border border-slate-100 group transition-all hover:border-blue-100">
                      <div className="flex items-center gap-3 flex-1 min-w-0">
                        {b === 'RBS' ? <Home className="w-4 h-4 text-blue-600 flex-shrink-0" /> : <Building className="w-4 h-4 text-slate-400 flex-shrink-0" />}
                        
                        {editingBranch === b ? (
                          <input
                            autoFocus
                            type="text"
                            value={editBranchValue}
                            onChange={(e) => setEditBranchValue(e.target.value)}
                            className="flex-1 bg-white border border-blue-500 rounded px-2 py-1 text-sm outline-none"
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleSaveEdit();
                              if (e.key === 'Escape') setEditingBranch(null);
                            }}
                          />
                        ) : (
                          <span className="font-bold text-slate-700 truncate">
                            {b} {b === 'RBS' && <span className="text-[10px] font-medium text-blue-500 ml-1">(HQ)</span>}
                          </span>
                        )}
                      </div>
                      
                      <div className="flex items-center gap-1">
                        {editingBranch === b ? (
                          <div className="flex gap-1">
                            <button onClick={handleSaveEdit} className="p-1.5 text-emerald-600 hover:bg-emerald-50 rounded transition-colors">
                              <Check className="w-4 h-4" />
                            </button>
                            <button onClick={() => setEditingBranch(null)} className="p-1.5 text-rose-600 hover:bg-rose-50 rounded transition-colors">
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        ) : (
                          <>
                            {b !== 'RBS' && (
                              <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-all">
                                <button 
                                  onClick={() => handleStartEdit(b)}
                                  className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors"
                                >
                                  <Edit2 className="w-4 h-4" />
                                </button>
                                <button 
                                  onClick={() => handleRemoveBranch(b)}
                                  className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            )}
                            <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-1 rounded ml-1">ACTIVE</span>
                          </>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <div className="p-6 bg-slate-50 rounded-xl text-center text-slate-500 italic text-sm border border-dashed border-slate-200">
                You do not have permission to manage branches.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminConsole;

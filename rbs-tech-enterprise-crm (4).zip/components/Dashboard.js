
import React, { useMemo, useState } from 'react';
import { 
  TrendingUp, Users, CheckCircle2, ArrowUpRight, 
  ArrowDownRight, Wallet, Filter, Calendar, 
  PhoneCall, DollarSign, PieChart as PieIcon, BarChart3
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { PremiumStatus, UserRole, QCStatus } from '../types.js';

const Dashboard = ({ state, user }) => {
  const [filterBranch, setFilterBranch] = useState('All');
  const [filterTime, setFilterTime] = useState('All Time');

  const filteredSales = useMemo(() => {
    let sales = state.sales;
    if (filterBranch !== 'All') sales = sales.filter(s => s.closerBranch === filterBranch);
    return sales;
  }, [state.sales, filterBranch]);

  const stats = useMemo(() => {
    const total = filteredSales.length;
    const approved = filteredSales.filter(s => s.qcStatus === QCStatus.APPROVED).length;
    const rejected = filteredSales.filter(s => s.qcStatus === QCStatus.REJECTED).length;
    const charged = filteredSales.filter(s => s.premiumStatus === PremiumStatus.CHARGED);
    const revenue = charged.reduce((acc, s) => acc + (s.actualPremiumAmount || 0), 0);
    const expenses = state.expenses.reduce((acc, e) => acc + e.amount, 0);
    const retention1 = filteredSales.filter(s => s.retentionCall1Done).length;
    const retention2 = filteredSales.filter(s => s.retentionCall2Done).length;

    return {
      total,
      approved,
      rejected,
      revenue,
      expenses,
      net: revenue - expenses,
      approvalRate: total > 0 ? ((approved / total) * 100).toFixed(1) : '0',
      retentionRate: total > 0 ? (((retention1 + retention2) / (total * 2)) * 100).toFixed(1) : '0',
      chargedCount: charged.length
    };
  }, [filteredSales, state.expenses]);

  const branchData = useMemo(() => {
    const branches = {};
    filteredSales.forEach(s => { branches[s.closerBranch] = (branches[s.closerBranch] || 0) + 1; });
    return Object.entries(branches).map(([name, value]) => ({ name, value }));
  }, [filteredSales]);

  const isExecutive = [UserRole.DIRECTOR, UserRole.GENERAL_MANAGER, UserRole.MANAGER].includes(user.role);

  return (
    <div className="space-y-8 pb-12">
      <div className="flex flex-col md:flex-row justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Management Dashboard</h1>
          <p className="text-slate-500">Business performance metrics.</p>
        </div>
        <div className="flex gap-3">
          <select value={filterBranch} onChange={(e) => setFilterBranch(e.target.value)} className="bg-white border p-2 rounded-xl text-sm">
            <option value="All">All Branches</option>
            {state.branches.map(b => <option key={b} value={b}>{b}</option>)}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {[
          { label: 'Gross Sales', val: stats.total, color: 'blue', icon: TrendingUp },
          { label: 'QC Approval', val: `${stats.approvalRate}%`, color: 'emerald', icon: CheckCircle2 },
          { label: 'Charged Premiums', val: stats.chargedCount, color: 'indigo', icon: DollarSign },
          { label: 'Retention Score', val: `${stats.retentionRate}%`, color: 'amber', icon: PhoneCall },
        ].map((kpi, idx) => (
          <div key={idx} className="bg-white p-6 rounded-2xl border shadow-sm">
             <kpi.icon className={`w-6 h-6 text-${kpi.color}-500 mb-2`} />
             <h3 className="text-xs font-bold text-slate-500 uppercase">{kpi.label}</h3>
             <p className="text-2xl font-black text-slate-800">{kpi.val}</p>
          </div>
        ))}
      </div>

      {isExecutive && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-slate-900 p-8 rounded-3xl text-white">
            <p className="text-slate-400 text-xs font-bold uppercase">Total Revenue</p>
            <h4 className="text-3xl font-black text-emerald-400">${stats.revenue.toLocaleString()}</h4>
          </div>
          <div className="bg-white p-8 rounded-3xl border">
            <p className="text-slate-500 text-xs font-bold uppercase">Total Expenses</p>
            <h4 className="text-3xl font-black text-rose-500">${stats.expenses.toLocaleString()}</h4>
          </div>
          <div className={`p-8 rounded-3xl text-white ${stats.net >= 0 ? 'bg-blue-600' : 'bg-rose-600'}`}>
            <p className="text-white/70 text-xs font-bold uppercase">Net Business Result</p>
            <h4 className="text-3xl font-black">${stats.net.toLocaleString()}</h4>
          </div>
        </div>
      )}

      <div className="bg-white p-8 rounded-3xl border shadow-sm h-80">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={branchData}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="value" fill="#3b82f6" radius={[8, 8, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default Dashboard;


import React, { useState } from 'react';
import { 
  User, 
  Phone, 
  Mail, 
  MapPin, 
  Car, 
  CreditCard, 
  ArrowRight, 
  CheckCircle2, 
  Building2 
} from 'lucide-react';
import { SaleRecord, QCStatus, ProcessingStatus, PremiumStatus, Branch, User as AppUser } from '../types';
import { USA_STATES, CAR_MAKES, CAR_MODELS_MAP } from '../constants';

interface SaleFormProps {
  onSubmit: (sale: SaleRecord) => void;
  currentUser: AppUser;
  branches: Branch[];
}

const SaleForm: React.FC<SaleFormProps> = ({ onSubmit, currentUser, branches }) => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<Partial<SaleRecord>>({
    frontierBranch: branches[0] || 'RBS',
    closerBranch: currentUser.branch || branches[0] || 'RBS',
    closerName: currentUser.fullName,
    carYear: 2024,
    state: 'Alabama',
    qcStatus: QCStatus.PENDING,
    processingStatus: ProcessingStatus.PENDING,
    premiumStatus: PremiumStatus.PENDING,
    incomeUpdated: false,
    retentionCall1Done: false,
    retentionCall2Done: false,
    qcNotes: '',
    processingComments: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    
    setFormData(prev => {
      const updates: any = {
        ...prev,
        [name]: type === 'number' ? parseFloat(value) : value
      };

      // Reset model if make changes
      if (name === 'carMake') {
        updates.carModel = '';
      }

      return updates;
    });
  };

  const handleNext = () => setStep(prev => prev + 1);
  const handlePrev = () => setStep(prev => prev - 1);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newSale: SaleRecord = {
      ...formData as SaleRecord,
      id: `S-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    onSubmit(newSale);
  };

  const years = Array.from({ length: 2024 - 2006 + 1 }, (_, i) => 2006 + i).reverse();

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-3xl shadow-xl overflow-hidden border border-slate-200">
        <div className="p-8 bg-slate-900 text-white flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-bold">New Warranty Sale</h2>
            <p className="text-slate-400">Step {step} of 3 — {step === 1 ? 'Team & Customer' : step === 2 ? 'Vehicle Details' : 'Policy Finalization'}</p>
          </div>
          <div className="flex gap-2">
            {[1, 2, 3].map(s => (
              <div key={s} className={`w-10 h-10 rounded-full flex items-center justify-center font-bold border-2 transition-all ${
                step === s ? 'bg-blue-600 border-blue-600 text-white' : step > s ? 'bg-emerald-500 border-emerald-500 text-white' : 'border-slate-700 text-slate-500'
              }`}>
                {step > s ? <CheckCircle2 className="w-6 h-6" /> : s}
              </div>
            ))}
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-8">
          {step === 1 && (
            <div className="space-y-6 animate-fadeIn">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-600 uppercase">Frontier Name</label>
                  <div className="relative">
                    <User className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                    <input name="frontierName" required onChange={handleChange} className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none transition-all" placeholder="John Doe" />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-600 uppercase">Frontier Branch</label>
                  <div className="relative">
                    <Building2 className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                    <select name="frontierBranch" value={formData.frontierBranch} onChange={handleChange} className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none appearance-none">
                      {branches.map(b => <option key={b} value={b}>{b}</option>)}
                    </select>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-600 uppercase">Closer Name</label>
                  <div className="relative">
                    <User className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                    <input name="closerName" required value={formData.closerName} onChange={handleChange} className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="Jane Smith" />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-600 uppercase">Closer Branch</label>
                  <div className="relative">
                    <Building2 className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                    <select name="closerBranch" value={formData.closerBranch} onChange={handleChange} className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none appearance-none">
                      {branches.map(b => <option key={b} value={b}>{b}</option>)}
                    </select>
                  </div>
                </div>
              </div>

              <hr className="border-slate-100" />

              <div className="space-y-4">
                <h3 className="font-bold text-lg text-slate-800 flex items-center gap-2"><User className="w-5 h-5" /> Customer Identity</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <input name="customerName" required onChange={handleChange} className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="Full Name" />
                  <input name="customerNumber" required onChange={handleChange} className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="Phone Number" />
                </div>
                <input name="email" type="email" required onChange={handleChange} className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="Email Address" />
                <input name="streetAddress" required onChange={handleChange} className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="Street Address" />
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <input name="city" required onChange={handleChange} className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="City" />
                  <select name="state" value={formData.state} onChange={handleChange} className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none">
                    {USA_STATES.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                  <input name="zipCode" required onChange={handleChange} className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="Zip Code" />
                </div>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6 animate-fadeIn">
              <h3 className="font-bold text-lg text-slate-800 flex items-center gap-2"><Car className="w-5 h-5" /> Vehicle Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-600 uppercase">Make</label>
                  <select name="carMake" required value={formData.carMake || ''} onChange={handleChange} className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none">
                    <option value="">Select Make</option>
                    {CAR_MAKES.map(m => <option key={m} value={m}>{m}</option>)}
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-600 uppercase">Model</label>
                  <select 
                    name="carModel" 
                    required 
                    value={formData.carModel || ''} 
                    onChange={handleChange} 
                    disabled={!formData.carMake}
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none disabled:bg-slate-50 disabled:text-slate-400"
                  >
                    <option value="">Select Model</option>
                    {formData.carMake && CAR_MODELS_MAP[formData.carMake]?.map(m => (
                      <option key={m} value={m}>{m}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-600 uppercase">Year</label>
                  <select name="carYear" value={formData.carYear} onChange={handleChange} className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none">
                    {years.map(y => <option key={y} value={y}>{y}</option>)}
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-600 uppercase">Mileage</label>
                  <input name="mileage" type="number" required onChange={handleChange} className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="Current Mileage" />
                </div>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-6 animate-fadeIn">
              <h3 className="font-bold text-lg text-slate-800 flex items-center gap-2"><CreditCard className="w-5 h-5" /> Policy Quote</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-600 uppercase">Total Policy Price ($)</label>
                  <input name="policyPrice" type="number" required onChange={handleChange} className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="2500.00" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-600 uppercase">Monthly Premium ($)</label>
                  <input name="monthlyPremium" type="number" required onChange={handleChange} className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="99.00" />
                </div>
              </div>
              <div className="p-6 bg-blue-50 rounded-2xl border border-blue-100 space-y-3">
                <div className="flex justify-between items-center text-sm font-medium">
                  <span className="text-blue-600">Calculated Down Payment:</span>
                  <span className="text-slate-700 font-bold">$199.00 (Example)</span>
                </div>
                <div className="flex justify-between items-center text-sm font-medium">
                  <span className="text-blue-600">Plan Duration:</span>
                  <span className="text-slate-700 font-bold">24 Months</span>
                </div>
              </div>
            </div>
          )}

          <div className="flex justify-between pt-6 border-t border-slate-100">
            {step > 1 ? (
              <button type="button" onClick={handlePrev} className="px-8 py-3 rounded-xl border border-slate-200 text-slate-600 font-bold hover:bg-slate-50 transition-colors">
                Back
              </button>
            ) : <div></div>}
            
            {step < 3 ? (
              <button type="button" onClick={handleNext} className="flex items-center gap-2 px-8 py-3 rounded-xl bg-blue-600 text-white font-bold hover:bg-blue-700 shadow-lg shadow-blue-500/20 transition-all">
                Continue <ArrowRight className="w-5 h-5" />
              </button>
            ) : (
              <button type="submit" className="flex items-center gap-2 px-8 py-3 rounded-xl bg-emerald-600 text-white font-bold hover:bg-emerald-700 shadow-lg shadow-emerald-500/20 transition-all">
                Submit Sale <CheckCircle2 className="w-5 h-5" />
              </button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
};

export default SaleForm;

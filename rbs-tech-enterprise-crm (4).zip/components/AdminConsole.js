
import React from 'react';
import { UserRole } from '../types.js';

const AdminConsole = ({ state, onUpdateState }) => {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Admin Console</h2>
      <div className="bg-white border p-8 rounded-3xl">
         <h3 className="font-bold text-slate-800 mb-4">Branch Management</h3>
         <div className="grid gap-2">
           {state.branches.map(b => (
             <div key={b} className="p-4 bg-slate-50 border rounded-xl font-bold text-slate-700">{b}</div>
           ))}
         </div>
      </div>
    </div>
  );
};

export default AdminConsole;


import React, { useState } from 'react';
import { XCircle, ArrowRightCircle, ShieldCheck, Clock, CreditCard, PhoneCall, CheckCircle } from 'lucide-react';
import { QCStatus, ProcessingStatus, PremiumStatus } from '../types.js';
import { CARRIERS } from '../constants.js';

const SalesManagement = ({ title, sales, onUpdate, type }) => {
  const [selectedSale, setSelectedSale] = useState(null);

  const getStatusBadge = (status) => {
    const s = status.toLowerCase();
    if (s.includes('approved') || s.includes('processed') || s.includes('charged')) return 'bg-emerald-50 text-emerald-700 border-emerald-100';
    if (s.includes('rejected') || s.includes('declined')) return 'bg-rose-50 text-rose-700 border-rose-100';
    return 'bg-slate-50 text-slate-700 border-slate-100';
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-slate-800">{title}</h2>
      <div className="bg-white rounded-2xl border shadow-sm overflow-hidden">
        <table className="w-full text-left text-sm">
          <thead className="bg-slate-50 border-b">
            <tr>
              <th className="px-6 py-4 font-bold text-slate-500 uppercase">Sale ID</th>
              <th className="px-6 py-4 font-bold text-slate-500 uppercase">Customer</th>
              <th className="px-6 py-4 font-bold text-slate-500 uppercase">Status</th>
              <th className="px-6 py-4 text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {sales.map(sale => (
              <tr key={sale.id} className="hover:bg-slate-50 transition-colors">
                <td className="px-6 py-4 font-bold">{sale.id}</td>
                <td className="px-6 py-4">{sale.customerName}</td>
                <td className="px-6 py-4">
                   <span className={`px-2 py-1 rounded-full text-[10px] font-bold border ${getStatusBadge(sale.qcStatus)}`}>{sale.qcStatus}</span>
                </td>
                <td className="px-6 py-4 text-right">
                  <button onClick={() => setSelectedSale(sale)} className="text-blue-500 hover:bg-blue-50 p-2 rounded-lg"><ArrowRightCircle className="w-5 h-5" /></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {selectedSale && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex justify-end">
          <div className="w-full max-w-xl bg-white h-full shadow-2xl animate-slideLeft p-8 overflow-y-auto custom-scrollbar">
            <div className="flex justify-between items-center mb-8">
               <h3 className="text-xl font-bold">Manage Case: {selectedSale.id}</h3>
               <button onClick={() => setSelectedSale(null)}><XCircle className="w-6 h-6 text-slate-400" /></button>
            </div>
            
            <div className="space-y-8">
              <section className="space-y-4">
                <h4 className="font-bold flex items-center gap-2"><ShieldCheck className="w-5 h-5 text-blue-500" /> QC Assessment</h4>
                <div className="flex gap-2">
                  {[QCStatus.APPROVED, QCStatus.REJECTED].map(s => (
                    <button key={s} onClick={() => onUpdate(selectedSale.id, { qcStatus: s })} className={`flex-1 py-2 border-2 rounded-xl text-sm font-bold ${selectedSale.qcStatus === s ? 'bg-blue-600 border-blue-600 text-white' : 'text-slate-500'}`}>{s}</button>
                  ))}
                </div>
              </section>

              {selectedSale.qcStatus === QCStatus.APPROVED && (
                <section className="space-y-4 animate-fadeIn">
                   <h4 className="font-bold flex items-center gap-2"><Clock className="w-5 h-5 text-amber-500" /> Processing</h4>
                   <select className="w-full p-3 border rounded-xl" onChange={e => onUpdate(selectedSale.id, { processingStatus: e.target.value })}>
                      {Object.values(ProcessingStatus).map(ps => <option key={ps} value={ps}>{ps}</option>)}
                   </select>
                </section>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SalesManagement;
